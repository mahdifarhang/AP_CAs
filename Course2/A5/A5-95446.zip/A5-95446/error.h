#ifndef ERROR_H_
#define ERROR_H_




class RowLengthExeption
{
public:
  RowLengthExeption() {}
};

class IndexOutOfBoundExeption
{
public:
  IndexOutOfBoundExeption() {}
};
class MatrixLengthExeption
{
public:
  MatrixLengthExeption() {}
};
class MatrixMultExeption
{
public:
  MatrixMultExeption() {}
};
class ConvolveExeption
{
public:
  ConvolveExeption() {}
};



#endif
